_T = int(raw_input())
for _t in range(1, _T+1):
  N, K = map(int, raw_input().split())
  A = map(int, raw_input().split())

  A.sort()
  day = 0
  res = 0
  for i in range(N):
    if A[i] <= day: continue
    res += 1
    if res%K == 0:
      day += 1
  
  print 'Case #{}: {}'.format(_t, res)
