# SoftwareEngineer-Summer-2018

### Steps to use this Demo Project

----------

1. Download / Clone this Repository on your system. 
1. Use the input.txt file as input to your code challenge

### Steps to Submit your New Project Code for the Challenge

-----------

1. Create a new Repo and push your new folder with your code files.

```If it is your first time, follow this guide: ```
[Guide](https://help.github.com/articles/create-a-repo/)

2. Copy paste the URL in the form answer.


-------------
